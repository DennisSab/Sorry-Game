package mvc.model.player;

/**
 * This enum contains the colors of the players
 */
public enum PlayerColor {
    RED,
    YELLOW;
}
