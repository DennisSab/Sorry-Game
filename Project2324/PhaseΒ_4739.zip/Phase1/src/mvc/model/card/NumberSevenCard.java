package mvc.model.card;

public class NumberSevenCard extends NumberCard{

    /**
     * Constructor that calls the super constructor
     * to create this type of card
     */
    public NumberSevenCard(){
        super(7,"mvc/images/cards/card7.png");
    };




}
