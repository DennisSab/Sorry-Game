package mvc.model.card;

import mvc.model.pawn.Pawn;

public class SorryCard extends NumberCard{

    public SorryCard(){
        super(6,"mvc/images/cards/cardSorry.png");
    };


}
