package model.card;

public class NumberFourCard extends NumberCard{


    /**
     * Constructor that calls the super constructor
     * to create this type of card
     */
    NumberFourCard(){
        super(-4);
    }

}
