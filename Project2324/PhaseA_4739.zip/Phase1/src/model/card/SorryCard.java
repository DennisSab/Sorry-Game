package model.card;

import model.pawn.Pawn;

import java.awt.*;
import java.io.PipedWriter;

public class SorryCard implements Card{

    /**
     * <b>Transformer:</b>in case of drawing sorry
     * card changes pawns positions if possible
     * <b>Precondition:</b>That pawn1 is in StartZone and pawn2 is not in a SafetyZone
     * <b>Postcondition:</b>Pawn's changed position or Turn changes
     * @param p1
     * @param p2
     */
    public void SorryCase(Pawn p1, Pawn p2){};

    SorryCard(){};

    @Override
    public int getValue() {
        return 0;
    }

    @Override
    public void setValue(int value) {

    }

    @Override
    public String getImage() {
        return null;
    }

    @Override
    public void setImage(Image image) {

    }

}
