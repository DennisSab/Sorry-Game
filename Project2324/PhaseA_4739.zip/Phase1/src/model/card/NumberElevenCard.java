package model.card;

import model.pawn.Pawn;

public class NumberElevenCard extends NumberCard{

    /**
     * Constructor that calls the super constructor
     * to create this type of card
     */
    NumberElevenCard(){
        super(11);
    }

    /**
     * <b>Accessor</b>method that indicates if we can change pawn with opponent
     * @return 1 in case we can change pawn with opponent
     */
    public int ChangePosOP(Pawn p1,Pawn p2){
        return 1;
    }
}
