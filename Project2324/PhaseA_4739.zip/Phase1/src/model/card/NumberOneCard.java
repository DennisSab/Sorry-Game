package model.card;


/**
 * Class for Number 1 card
 */
public class NumberOneCard extends NumberCard{


    /**
     * Constructor that calls the super constructor
     * to create this type of card
     */
    NumberOneCard(){
        super(1);
    }

    /**
     * <b>Accessor</b>:indicates that we have the option
     * to go to the start
     * @return 1 to have the option to get to start
     */
    public int GoToStart(){
        return 1;
    }


}
