package model.card;

/**
 * this class is about 3,5,8,12 cards
 */

public class SimpleNumberCard extends NumberCard{

    private int value;

    /**
     * Constructor
     * @param value
     */
    SimpleNumberCard(int value){
        super(value);
    }

    //setters and getters
    public void setValue(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
