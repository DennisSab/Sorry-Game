package model.card;

public class NumberTwoCard extends NumberCard{

    /**
     * Constructor that calls the super constructor
     * to create this type of card
     */
    NumberTwoCard(){
        super(2);
    }
}
