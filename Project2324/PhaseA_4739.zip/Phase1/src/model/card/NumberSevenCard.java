package model.card;

public class NumberSevenCard extends NumberCard{

    /**
     * Constructor that calls the super constructor
     * to create this type of card
     */
    NumberSevenCard(){
        super(7);
    };


    /**
     * <b>transformer(mutative):</b>decides if we move our pawns 7-0,6-1,5-2,4-3
     */
    public void decideMove(){}
}
