package model.pawn;

import model.player.Player;

import java.awt.*;

public class Pawn {

    private Color color;

    private String name;
    public Pawn(String name, Player player, Color color){
        this.name=name;
        this.color=color;
    };

    /**
     * <b>Accessor:</b>gets the position of this pawn
     * @return the current position of this pawn
     */
    public int getPos(Pawn pawn){
        return 0;
    };

    /**
     * <b>Transformer:</b>Method to set the Position of the pawn
     * <b>Post-Condition:</b>new position has been set
     */
    public void setPos(){};

    /**
     * Gets the color of the pawn.
     *
     * @return The color of the pawn.
     */
    public Color getColor() {
        return color;
    }

    /**
     * Sets the color of the pawn.
     *
     * @param color The color to set for the pawn.
     */
    public void setColor(Color color) {
        this.color = color;
    }

    /**
     * Gets the name of the pawn.
     *
     * @return The name of the pawn.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the pawn.
     *
     * @param name The name to set for the pawn.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * <b>Transformer:</b>Sets the current position as the start position of this pawn
     * <b>Post-Condition:</b>this pawn's position has been set to start
     */
    public void setStartPos(){};


    /**
     * Moves the pawn a specified number of steps.
     *
     * <p>
     * <b>Transformer:</b> Moves the pawn to a new position based on the specified number of steps.
     * <b>Pre-Condition:</b> The pawn must have a valid position before calling this method.
     * <b>Post-Condition:</b> The pawn's position is updated according to the specified number of steps.
     * </p>
     *
     * @param steps The number of steps to move the pawn
     */
    public void movePawn(int steps){};


}
