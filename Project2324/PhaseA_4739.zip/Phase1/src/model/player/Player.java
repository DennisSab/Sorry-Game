package model.player;



public class Player {
    private String name;
    private PlayerColor color;
    private int ID;

    /**
     * 
     * @param name
     * @param color
     * @param ID
     */
    public Player(String name, PlayerColor color,int ID){
        this.name=name;
        this.color=color;
        this.ID=ID;
    }

    /**
     * <b>Transformer:</b>sets the players pawns
     */
    public void setPawns(){};

    //setters and getters for name and color
    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public PlayerColor getColor() {
        return color;
    }

    public void setColor(PlayerColor color) {
        this.color = color;
    }
}
