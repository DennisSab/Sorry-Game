package model.turn;

/**
 * This class decides the turn of the game
 */
public class Turn {

    /**
     * <b>Accessor:</b>method that indicates whom player's turn is
     * @return which player plays
     */
    public int GetTurn(){
        return 0;
    };

    /**
     * <b>Transformer:</b>sets the turn
     * <b>Post-Condition:</b> sets the right turn for the player to play
     */
    public void setTurn(){

    }
}
