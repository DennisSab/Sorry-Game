package model.square;

public interface Square {

    /**
     *<b>Transformer:</b>method to set the position of this square
     *<b>Post-Condition:</b>position of this square has been has
     */
    public void setPosition();

    /**
     *<b>Accessor:</b>method to set the position of this square
     * @return the position of this square
     */
    public int getPosition();


    /**
     * <b>Observer:</b>checks if the current square has a pawn on it
     * @return 0 for no,1 for yes
     */
    public int hasPawnOn();

    /**
     * <b>Observer:</b>checks if the current square has no pawn on it
     * @return 1 if empty
     */
    public int IsEmptySquare();

    /**
     * <b>Transformer:</b>Sets the image for the current square
     */
    public void setImage();

    /**
     * <b>Accessor:</b>gets the image for the current square
     * @return the image of the current square
     */
    public String getImage();




}
