package model.square;

public class EndSlideSquare extends SlideSquare{
}
