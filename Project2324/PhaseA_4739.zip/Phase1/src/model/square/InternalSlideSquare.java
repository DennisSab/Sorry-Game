package model.square;

public class InternalSlideSquare extends SlideSquare{
}
