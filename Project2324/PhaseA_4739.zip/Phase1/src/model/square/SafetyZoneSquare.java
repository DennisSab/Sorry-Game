package model.square;

public class SafetyZoneSquare implements Square{

    @Override
    public void setPosition() {

    }

    @Override
    public int getPosition() {
        return 0;
    }

    @Override
    public int hasPawnOn() {
        return 0;
    }

    @Override
    public int IsEmptySquare() {
        return 0;
    }

    @Override
    public void setImage() {

    }

    @Override
    public String getImage() {
        return null;
    }
}
