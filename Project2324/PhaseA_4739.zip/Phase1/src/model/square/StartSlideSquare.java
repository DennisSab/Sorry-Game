package model.square;

public class StartSlideSquare extends SlideSquare{
}
