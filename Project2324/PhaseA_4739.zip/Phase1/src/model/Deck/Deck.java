package model.Deck;

import model.card.Card;
import java.util.ArrayList;
import java.util.List;

/**
 * Class to represent a deck of cards
 */
public class Deck  {

    private final List<Card> cards;

    /**
     * <b>Constructor</b>
     * <b>Postcondition:</b>Creates a new Deck of cards with ArrayList
     */
    public Deck(){
        this.cards=new ArrayList<Card>();
    }


    /**
     * method that indicates how many cards are left on the deck
     * @return number of cards left on the deck
     */
    public int cardOnBoard(){return 0;};

    /**
     * <b>Transformer:</b>Initializes and shuffles the 44 cards
     * <b>Postcondition:</b>The cards have been initialized and shuffled
     */
    public void init_cards(){};

    /**
     * <b>Observer:</b>Returns true if this list has no elements
     * <b>Postcondition:</b>Returns true if this list has no elements
     * @return true if this list has no elements
     */
    public boolean isEmpty(){return false;}

    /**
     * <b>Accessor:</b> returns the card's value
     * <b>Postcondition:</b> card's value has been returned
     * @return value of card
     */
    public int getValue(int i){
        return cards.get(i).getValue();
    }

    /**
     * <b>Transformer:</b> removes a card from the list
     * <b>Postcondition:</b> A card has been removed
     * @param i
     */
    public void removeCard(Card i){
        this.cards.remove(i);
    }

    /**
     * <b>Transformer:</b> Returns the size of a list.
     * <Postcondition:</b> The size of the list has been returned.
     * @return size of the list
     */
    public int size(){
        return cards.size();
    }

    /**
     * <b>Accessor:</b> returns the card in position 'index'
     * <b>Postcondition:</b> the card in position 'index' has been returned
     * @return the card in position 'index'
     */
    public Card getCard(int index){
        return cards.get(index);
    }

    /**
     * <b>Accessor:</b> returns all the cards
     * <b>Postcondition:</b> all the cards has been returned
     * @return all the cards
     */
    public List<Card> getAllCards() {
        return cards;
    }
}
