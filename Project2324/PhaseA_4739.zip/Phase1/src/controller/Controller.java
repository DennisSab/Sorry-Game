package controller;


import model.Deck.Deck;
import model.pawn.Pawn;
import model.player.Player;
import model.player.PlayerColor;

import java.awt.*;

/**
 * Controller is the master of the game and controls all
 * the operations executed
 */
public class Controller {



    /**
     * <b>Constructor:</b>creates a new instance of Controller which sets the game ready to start <br />
     * <b>Post-Condition:</b>sets the game ready to start
     */
    public Controller(){
        Player p1=new Player("p1", PlayerColor.RED,1);
        Player p2=new Player("p2",PlayerColor.YELLOW,2);
        Pawn pawn1=new Pawn("p1",p1, Color.RED);
        Pawn pawn2=new Pawn("p2",p2, Color.YELLOW);


    };

    /**
     * <b>transformer(mutative):</b> initializes cards
     * <p><b>Post-Condition:</b>initializes cards at the beginning</p>
     */
    public void setCards() {}

    /**
     * <b>transformer(mutative):</b>if a player presses the button fold
     * gives the turn to the next player
     * <p><b>Post-Condition:</b>give the turn to the next player</p>
     */
    public void setFold() {}

    /**
     * <b>Observer:</b>Method to see the current turn
     * @return the player that plays now
     */
    public int seeTurn(){
        return 0;
    }

    /**
     * <b>Observer:</b>Return true if game is finished,false otherwise
     * <p><b>Post-Condition:</b>Return true if a player has all of his pawns at the home position</p>
     * @return true is game finished,false otherwise
     */
    public boolean game_finished(){return false;}


    /**
     * Sets up the game board.
     *
     * <p>
     * <b>Transformer:</b> Prepares and initializes the game board for play.
     * <b>Pre-Condition:</b> The game board should be in its initial state before calling this method.
     * <b>Post-Condition:</b> The game board is configured and ready for use.
     * </p>
     */
    public void setBoard(){}


    /**
     * Draws a card from the deck.
     *
     * <p>
     * <b>Transformer:</b> Retrieves a card from the deck and adds it to the player's hand or the game's active cards.
     * <b>Pre-Condition:</b> The deck should not be empty before calling this method.
     * <b>Post-Condition:</b> A card is drawn from the deck and added to the player's hand or the active cards in the game.
     * </p>
     */
    public void drawCard() {}




    public static void main(String[] args) {
        System.out.println("Hello world!");
    }

}
