package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

public class GraphicUI extends JFrame {

    private Image image;
    private JButton FoldButton;
    private JMenuBar menuBar ;

    private myDesktopPane basic_panel;
    private URL imageURL;

    private JTextArea InfoArea;
    private JLayeredPane panel;

    /**
     * <b>constructor</b>:Creates a new window and initializes
     * some buttons and panels
     */
    public GraphicUI(){

    }

    /**
     * <b>transformer</b>:initializes some buttons and labels<br />
     * <p><b>Postcondition:</b>initializes some buttons and labels</p>
     */
    private void initComponents(){}

    /**
     * <b>transformer:</b>sets some buttons and labels
     * <b>Post-Condition:</b>sets some buttons and labels
     */
    private void init_buttons(){}


    /**
     * Class which is used to put a background scene
     */
    public class myDesktopPane extends JDesktopPane{
        private Image image;

        public myDesktopPane(){}

        @Override
        public void paintComponent(Graphics g){
            super.paintComponent(g);
            g.drawImage(image,0,0,this);
        }
    }




    /** a class which is used for doing some action after Fold button has been pushed */
    private class FoldListener implements ActionListener {
        /**
         * <b>transformer(mutative)</b>:doing some action after Fold has been pushed<br />
         * <p><b>Postcondition:</b> doing some action after Fold button has been pushed</p>
         *
         */
        @Override
        public void actionPerformed(ActionEvent e) {

        }
    }

}
